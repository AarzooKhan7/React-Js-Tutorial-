<!DOCTYPE html>
<html>
<head>
	<title>Sign Up - Alpha EduWorld</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>body {
	background: #1690A7;
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	flex-direction: column;
}

*{
	font-family: sans-serif;
	box-sizing: border-box;
}

form {
	width: 500px;
	border: 2px solid #ccc;
	padding: 30px;
	background: #fff;
	border-radius: 15px;
}

h2 {
	text-align: center;
	margin-bottom: 40px;
}

input {
	display: block;
	border: 2px solid #ccc;
	width: 95%;
	padding: 10px;
	margin: 10px auto;
	border-radius: 5px;
}
label {
	color: #888;
	font-size: 18px;
	padding: 10px;
}

button {
	float: right;
	background: #555;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}
.error {
   background: #F2DEDE;
   color: #A94442;
   padding: 10px;
   width: 95%;
   border-radius: 5px;
   margin: 20px auto;
}

.success {
   background: #D4EDDA;
   color: #40754C;
   padding: 10px;
   width: 95%;
   border-radius: 5px;
   margin: 20px auto;
}

h1 {
	text-align: center;
	color: #fff;
}

.ca {
	font-size: 14px;
	display: inline-block;
	padding: 10px;
	text-decoration: none;
	color: #444;
}
.ca:hover {
	text-decoration: underline;
}</style>
</head>
<body>
	<br><br><br><br><br><br><br><br>	<br><br><br><br><br><br><br><br><br><br>	<br><br><br><br><br><br><br><br><br><br>
     <form action="signup-check.php" method="post">
     	<h2>SIGN UP</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>

          <?php if (isset($_GET['success'])) { ?>
               <p class="success"><?php echo $_GET['success']; ?></p>
          <?php } ?>

          <label>Name</label>
          <?php if (isset($_GET['name'])) { ?>
               <input type="text" 
                      name="name" 
                      placeholder="Name"
                      value="<?php echo $_GET['name']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="name" 
                      placeholder="Name"><br>
          <?php }?>

          <label>User Name</label>
          <?php if (isset($_GET['uname'])) { ?>
               <input type="text" 
                      name="uname" 
                      placeholder="User Name"
                      value="<?php echo $_GET['uname']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="uname" 
                      placeholder="User Name"><br>
          <?php }?>


     	<label>Password</label>
     	<input type="password" 
                 name="password" 
                 placeholder="Password"><br>

          <label>Confirm Password</label>
          <input type="password" 
                 name="re_password" 
                 placeholder="Confirm Password"><br>

				 <label>Email</label>
          <?php if (isset($_GET['email'])) { ?>
               <input type="text" 
                      name="email" 
                      placeholder="Email"
                      value="<?php echo $_GET['email']; ?>"><br>
          <?php }else{ ?>
               <input type="email" 
                      name="email" 
                      placeholder="Email Address"><br>
          <?php }?>


		  <label>Mobile</label>
          <?php if (isset($_GET['mobile'])) { ?>
               <input type="text" 
                      name="mobile" 
                      placeholder="Phone Number"
                      value="<?php echo $_GET['mobile']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="mobile" 
                      placeholder="Phone Number"><br>
          <?php }?>


		  <label>Country</label>
          <?php if (isset($_GET['country'])) { ?>
               <input type="text" 
                      name="country" 
                      placeholder="Country"
                      value="<?php echo $_GET['country']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="country" 
                      placeholder="Country"><br>
          <?php }?>
		  
		  <label>State</label>
          <?php if (isset($_GET['state'])) { ?>
               <input type="text" 
                      name="state" 
                      placeholder="State"
                      value="<?php echo $_GET['state']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="state" 
                      placeholder="state"><br>
          <?php }?>

		  <label>Course</label>
          <?php if (isset($_GET['course'])) { ?>
               <input type="text" 
                      name="course" 
                      placeholder="Course"
                      value="<?php echo $_GET['course']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="course" 
                      placeholder="course"><br>
          <?php }?>

		  <label>University</label>
          <?php if (isset($_GET['university'])) { ?>
               <input type="text" 
                      name="university" 
                      placeholder="university"
                      value="<?php echo $_GET['university']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="university" 
                      placeholder="university"><br>
          <?php }?>

		  <label>Aadhaar Number</label>
          <?php if (isset($_GET['aadhaar'])) { ?>
               <input type="text" 
                      name="aadhaar" 
                      placeholder="Enter your 12-digit Aadhaar number"
                      value="<?php echo $_GET['aadhaar']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="aadhaar" 
                      placeholder="aadhaar"><br>
          <?php }?>

		  <label>Passport</label>
          <?php if (isset($_GET['passport'])) { ?>
               <input type="text" 
                      name="passport" 
                      placeholder="Enter your Passport number"
                      value="<?php echo $_GET['passport']; ?>"><br>
          <?php }else{ ?>
               <input type="text" 
                      name="passport" 
                      placeholder="passport"><br>
          <?php }?>
		  
















     	<button type="submit">Sign Up</button>
          <a href="index.php" class="ca">Already have an account?</a>
     </form>
</body>
</html>