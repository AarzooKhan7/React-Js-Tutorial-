<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Details - Alpha EduWorld</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<style>body {
	background: white;
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100vh;
	flex-direction: column;
}

*{
	font-family: sans-serif;
	box-sizing: border-box;
}

form {
	width: 500px;
	border: 2px solid #ccc;
	padding: 30px;
	background: #fff;
	border-radius: 15px;
}

h2 {
	text-align: center;
	margin-bottom: 40px;
}

h1{
	color:black;
}
input {
	display: block;
	border: 2px solid #ccc;
	width: 95%;
	padding: 10px;
	margin: 10px auto;
	border-radius: 5px;
}
label {
	color: #888;
	font-size: 18px;
	padding: 10px;
}

button {
	float: right;
	background: #555;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
button:hover{
	opacity: .7;
}
.error {
   background: #F2DEDE;
   color: #A94442;
   padding: 10px;
   width: 95%;
   border-radius: 5px;
   margin: 20px auto;
}

.success {
   background: #D4EDDA;
   color: #40754C;
   padding: 10px;
   width: 95%;
   border-radius: 5px;
   margin: 20px auto;
}

h1 {
	text-align: center;
	color: #fff;
}

.ca {
	font-size: 14px;
	display: inline-block;
	padding: 10px;
	text-decoration: none;
	color: #444;
}
.ca:hover {
	text-decoration: underline;
}
.boxx{
	width:36vh;
}

@media only screen and (max-width: 800px) {
 
}
</style>
</head>
<body>

<h4 style="color:black;">Application Details</h4><br>
     <h1 style="color:black;">Hello, <?php echo $_SESSION['name']; ?></h1>











	 <section id="main-site" style="margin-left:-180px; ">
    <div class="container py-5">
        <div class="row">
            <div class="col-4 offset-4 shadow py-4 boxx">
                

                <div class="user-info px-3" >
                    <ul class="font-ubuntu navbar-nav">
                        <li class="nav-link" style="color:black;"><b>Name: </b><span><?php echo $_SESSION['name']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Email: </b><span><?php echo $_SESSION['email']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Mobile: </b><span><?php echo $_SESSION['mobile']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Country: </b><span><?php echo $_SESSION['country']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>State: </b><span><?php echo $_SESSION['state']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Course: </b><span><?php echo $_SESSION['course']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>University: </b><span><?php echo $_SESSION['university']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Aadhaar Number: </b><span><?php echo $_SESSION['aadhaar']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Passport Number: </b><span><?php echo $_SESSION['passport']; ?></span></li>
						<li class="nav-link" style="color:black;"><b>Attachment: </b><span><a href="download.php?id=<?php echo $row['attachment'] ?>" class="btn btn-primary">download</a></span></li>
						
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>


<div style="display:flex; flex-direction:row;">
<a href="https://www.alphaeduworld.com"><button type="button" class="btn btn-success">Go to home</button></a>
<a href="signup.php"><button type="button" class="btn btn-primary">Apply another form</button></a>
<a href="logout.php"><button type="button" class="btn btn-danger">Log out</button></a>
</div>


</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>
