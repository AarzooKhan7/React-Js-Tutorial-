jQuery(document).ready(function() {
	
	"use strict";
	// Your custom js code goes here.

});
 function yesnoCheck(that) {
    if (that.value == "other") {
  
        document.getElementById("ifYes").style.display = "block";
    } else {
        document.getElementById("ifYes").style.display = "none";
    }
}


 

   function f1()
        {
          // document.write('option changed!');
          var v=document.getElementById("s");
          var v1=document.getElementById("myinst");
          if(v.value=="o")
          {
             v1.style.display='block';
          }
          else
          {
             v1.style.display='none';
          }
        }



function myFunction() { 

            var demo = document.getElementById("my-form"); 

            demo.style.display = "block"; 

    			}


var owl = $('.owl-carousel');
owl.owlCarousel({
    items:1,
    loop:true,
    autoplay:true,
    autoplayTimeout:1700,
    autoplayHoverPause:true
});
