<?php 

if (isset($_POST['create'])) {
	include "../db_conn.php";
	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$mobile = validate($_POST['mobile']);
	$country = validate($_POST['country']);
	$state = validate($_POST['state']);
	$course = validate($_POST['course']);
	$university = validate($_POST['university']);
	$user_name = validate($_POST['user_name']);
	$password = validate($_POST['password']);
	$aadhaar = validate($_POST['aadhaar']);
	$passport = validate($_POST['passport']);
	$attachment = validate($_POST['attachment']);


	$user_data = 'name='.$name. '&email='.$email;

	if (empty($name)) {
		header("Location: ../index.php?error=Name is required&$user_data");
	}else if (empty($email)) {
		header("Location: ../index.php?error=Email is required&$user_data");
	}else {

       $sql = "INSERT INTO users(name, email, mobile, country, state, course, university, user_name, password, aadhaar, passport, attachment) 
               VALUES('$name', '$email', '$mobile', '$country', '$state', '$course', '$university', '$user_name', '$password', '$aadhaar', '$passport', '$attachment')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../read.php?success=successfully created");
       }else {
          header("Location: ../index.php?error=unknown error occurred&$user_data");
       }
	}

}