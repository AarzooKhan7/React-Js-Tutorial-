<?php include 'php/update.php'; ?>
<?php  if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: /index.html');
    exit;
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Student Details - Admin - Alpha EduWorld</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    	<br><br>	<br>
	<div class="container">
		<form action="php/update.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Update details</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>


		   <div class="form-group">
		     <label for="name">Name</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="name" 
		           value="<?=$row['name'] ?>" >
		   </div>

		   <div class="form-group">
		     <label for="email">Email</label>
		     <input type="email" 
		           class="form-control" 
		           id="email" 
		           name="email" 
		           value="<?=$row['email'] ?>" >
		   </div>

		   <div class="form-group">
		     <label for="user_name">User Name</label>
		     <input type="text" 
		           class="form-control" 
		           id="user_name" 
		           name="user_name" 
		           value="<?=$row['user_name'] ?>" >
		   </div>


		   <div class="form-group">
		     <label for="mobile">Phone Number</label>
		     <input type="text" 
		           class="form-control" 
		           id="mobile" 
		           name="mobile" 
		           value="<?=$row['mobile'] ?>" >
		   </div>


		   <div class="form-group">
		     <label for="country">Country</label>
		     <input type="text" 
		           class="form-control" 
		           id="country" 
		           name="country" 
		           value="<?=$row['country'] ?>" >
		   </div>


		   <div class="form-group">
		     <label for="state">State</label>
		     <input type="text" 
		           class="form-control" 
		           id="state" 
		           name="state" 
		           value="<?=$row['state'] ?>" >
		   </div>


		   <div class="form-group">
		     <label for="course">Course</label>
		     <input type="text" 
		           class="form-control" 
		           id="course" 
		           name="course" 
		           value="<?=$row['course'] ?>" >
		   </div>



		   <div class="form-group">
		     <label for="university">University</label>
		     <input type="text" 
		           class="form-control" 
		           id="university" 
		           name="university" 
		           value="<?=$row['university'] ?>" >
		   </div>

		   <div class="form-group">
		     <label for="aadhaar">Aadhaar Number</label>
		     <input type="text" 
		           class="form-control" 
		           id="aadhaar" 
		           name="aadhaar" 
		           value="<?=$row['aadhaar'] ?>" >
		   </div>


		   <div class="form-group">
		     <label for="passport">Passport</label>
		     <input type="text" 
		           class="form-control" 
		           id="passport" 
		           name="passport" 
		           value="<?=$row['passport'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="attachment">Attachment</label>
		     <input type="file" 
		           class="form-control" 
		           id="attachment" 
		           name="attachment" 
		           value="<?=$row['attachment'] ?>" >
		   </div>



















		   <input type="text" 
		          name="id"
		          value="<?=$row['id']?>"
		          hidden >

		   <button type="submit" 
		           class="btn btn-primary"
		           name="update">Update</button>
		     <button class="btn btn-success"><a href="read.php" style="color:white;">View</a></button> 
	    </form>
	</div>

		<br><br>
	
	<center><p>Alpha EduWorld &copy; 2022. All rights reverved</p></center>
</body>
</html>