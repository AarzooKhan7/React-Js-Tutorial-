<?php  

$sname = "localhost";
$uname = "alphaeduworld";
$password = "alphaeduworld";

$db_name = "test_db";

$conn  = mysqli_connect("localhost", "alphaeduworld", "alphaeduworld", "test_db");

if (!$conn) {
	echo "Connection failed!";
}