<?php  if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: /index.html');
    exit;
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin - Create User</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body><br><br>
	<div class="container">
		<form action="php/create.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Create User</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Name</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="name" 
		           value="<?php if(isset($_GET['name']))
		                           echo($_GET['name']); ?>" 
		           placeholder="Enter name">
		   </div>

		   <div class="form-group">
		     <label for="email">Email</label>
		     <input type="email" 
		           class="form-control" 
		           id="email" 
		           name="email" 
		           value="<?php if(isset($_GET['email']))
		                           echo($_GET['email']); ?>"
		           placeholder="Enter email">
		   </div>
		   
		   <div class="form-group">
		     <label for="mobile">Phone Number</label>
		     <input type="text" 
		           class="form-control" 
		           id="mobile" 
		           name="mobile" 
		           value="<?php if(isset($_GET['mobile']))
		                           echo($_GET['mobile']); ?>"
		           placeholder="Enter Phone Number">
		   </div>


		   <div class="form-group">
		     <label for="country">Country</label>
		     <input type="text" 
		           class="form-control" 
		           id="country" 
		           name="country" 
		           value="<?php if(isset($_GET['country']))
		                           echo($_GET['country']); ?>"
		           placeholder="Enter Country's name">
		   </div>



		   <div class="form-group">
		     <label for="state">State</label>
		     <input type="text" 
		           class="form-control" 
		           id="state" 
		           name="state" 
		           value="<?php if(isset($_GET['state']))
		                           echo($_GET['state']); ?>"
		           placeholder="Enter State's name">
		   </div>

		   <div class="form-group">
		     <label for="course">Course</label>
		     <input type="text" 
		           class="form-control" 
		           id="course" 
		           name="course" 
		           value="<?php if(isset($_GET['course']))
		                           echo($_GET['course']); ?>"
		           placeholder="Enter Course name">
		   </div>


		   <div class="form-group">
		     <label for="university">University</label>
		     <input type="text" 
		           class="form-control" 
		           id="university" 
		           name="university" 
		           value="<?php if(isset($_GET['university']))
		                           echo($_GET['university']); ?>"
		           placeholder="Enter University's name">
		   </div>


		   <div class="form-group">
		     <label for="user_name">User Name</label>
		     <input type="text" 
		           class="form-control" 
		           id="user_name" 
		           name="user_name" 
		           value="<?php if(isset($_GET['user_name']))
		                           echo($_GET['user_name']); ?>"
		           placeholder="Choose User name">
		   </div>




		   <div class="form-group">
		     <label for="password">Password</label>
		     <input type="text" 
		           class="form-control" 
		           id="password" 
		           name="password" 
		           value="<?php if(isset($_GET['password']))
		                           echo($_GET['password']); ?>"
		           placeholder="Create a password">
		   </div>


		   <div class="form-group">
		     <label for="aadhaar">Aadhaar Number</label>
		     <input type="text" 
		           class="form-control" 
		           id="aadhaar" 
		           name="aadhaar" 
		           value="<?php if(isset($_GET['aadhaar']))
		                           echo($_GET['aadhaar']); ?>"
		           placeholder="Enter Aadhaar Number">
		   </div>


		   <div class="form-group">
		     <label for="passport">Passport</label>
		     <input type="text" 
		           class="form-control" 
		           id="passport" 
		           name="passport" 
		           value="<?php if(isset($_GET['passport']))
		                           echo($_GET['passport']); ?>"
		           placeholder="Enter Passport Number">
		   </div>

		   
		   <div class="form-group">
		     <label for="attachment">Attachment</label>
		     <input type="file" 
		           class="form-control" 
		           id="attachment" 
		           name="attachment" 
		           value="<?php if(isset($_GET['attachment']))
		                           echo($_GET['attachment']); ?>"
		           placeholder="Upload Attachment">
		   </div>






		   <button type="submit" 
		          class="btn btn-primary"
		          name="create">Create</button>
		          
		     <button class="btn btn-success"><a href="read.php" style="color:white;">View</a></button>      
		    
	    </form>
	</div>
	
		<br><br><br>
	
	
	<center><p>Alpha EduWorld &copy; 2022. All rights reverved</p></center>
</body>
</html>