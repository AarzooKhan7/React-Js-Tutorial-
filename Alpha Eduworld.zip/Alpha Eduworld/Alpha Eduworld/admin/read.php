<?php include "php/read.php"; ?>
<?php  if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: /index.html');
    exit;
}?>
<!DOCTYPE html>
<html>
<head>
	<title>Alpha EduWorld - User Details</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<style>
	@media only screen and (min-width: 800px) {
	    table{
	        position:relative;
	        left:-100px;
	    }

	
}

	@media only screen and (max-width: 600px) {
	    table{
	        margin-left:100px;
	    }
	    
	   
}
</style>
	<div class="container" style="position:relative; right:100px;">
		<div class="box">
			<h4 class="display-4 text-center" style="position:relative; left:140px;">Students Details</h4><br>
			<?php if (isset($_GET['success'])) { ?>
		    <div class="alert alert-success" role="alert">
			  <?php echo $_GET['success']; ?>
		    </div>
		    <?php } ?>
			<?php if (mysqli_num_rows($result)) { ?>
			<table class="table table-striped">
			  <thead>
			    <tr>
			      <th scope="col">#</th>
			      <th scope="col">Name</th>
			      <th scope="col">Email</th>
				  <th scope="col">User Name</th>
				  <th scope="col">Phone Number</th>
				  <th scope="col">Country</th>
				  <th scope="col">State</th>
				  <th scope="col">Course</th>
				  <th scope="col">University</th>
				  <th scope="col">Aadhaar Number</th>
				  <th scope="col">Passport Number</th>




			      <th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php 
			  	   $i = 0;
			  	   while($rows = mysqli_fetch_assoc($result)){
			  	   $i++;
			  	 ?>
			    <tr>
			      <th scope="row"><?=$i?></th>
			      <td><?=$rows['name']?></td>
			      <td><?php echo $rows['email']; ?></td>
				  <td><?php echo $rows['user_name']; ?></td>
				  <td><?php echo $rows['mobile']; ?></td>
				  <td><?php echo $rows['country']; ?></td>
				  <td><?php echo $rows['state']; ?></td>
				  <td><?php echo $rows['course']; ?></td>
				  <td><?php echo $rows['university']; ?></td>
				  <td><?php echo $rows['aadhaar']; ?></td>
				  <td><?php echo $rows['passport']; ?></td>






			      <td>
<a href="https://sg2plzcpnl490066.prod.sin2.secureserver.net:2083/cpsess8248786503/3rdparty/phpMyAdmin/sql.php" 
			      	     class="btn btn-success">Update</a>
			      	  <a href="php/delete.php?id=<?=$rows['id']?>" 
			      	     class="btn btn-danger">Delete</a>
			      </td>
			    </tr>
			    <?php } ?>
			  </tbody>
			</table>
			<?php } ?>
			
			
			
			<br>
			<div class="link-left" id="btt">
			    
			    <a href="https://www.alphaeduworld.com/student/signup.php" class="link-primary" style="color:white;"><button type="button" class="btn btn-success">Create new record</button></a> <a href="https://www.alphaeduworld.com" class="link-primary" style="color:white;"><button type="button" class="btn btn-primary">Go To Home</button></a>
				
			</div>
		</div>
	</div>



	
	<center><p>Alpha EduWorld &copy; 2022. All rights reverved</p></center>
</body>
</html>